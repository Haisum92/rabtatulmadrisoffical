<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="/rabta/css/custom.css" type="text/css" />
<title>Exam Attendance Sheet</title>
<style type="text/css">

.rightAlign {
	text-align: right;
}
.centerAlign {
	text-align: center;
}

.leftAlign {
	text-align: left;
}
.border {
	border-style:solid;
	border-width:1px;
}
.borderBottom{
/*	border-bottom:solid;
	/*border-style:solid;*/
	/*border-width:1px;*/
	
}

.tablee {
	width: 600px;
	margin:auto;
}
.title {
	font-size:36px;
}
.pad {
	padding:10px;
	margin-bottom:20px;
}
.limited{
	margin-right:10px;
	}
#dostyle{
font-family: "Alvi Nastaleeq", Verdana, Arial, Helvetica, sans-serif;
color: 
black;
font-size: 16px;
direction: rtl;
}
</style>
</head>

<body>

</body>
</html>