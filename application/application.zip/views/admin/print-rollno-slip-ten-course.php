<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Print Roll No Slips</title>
<style type="text/css">
body {
  font-family: "Alvi Nastaleeq",Helvetica,Arial,sans-serif;
  font-size: 16px;
  line-height: 1.42857143;
  color: #333;
  background-color: #fff;
  }
.rightAlign {
	text-align: right;
}
.centerAlign {
	text-align: center;
}
.leftAlign {
	text-align: left;
}
.border {
	border-style:solid;
	border-width:1px;
}
.tablee {
	width: 600px;
	margin:auto;
	padding-bottom: 20px;
}
.title {
	font-size:36px;
}
.pad {
	padding: 10px;
	/*  margin-bottom: 34px;*/
	  width: 700px;
	  margin: 0px auto 20px;

}
#dostyle{
font-family: "Alvi Nastaleeq", Verdana, Arial, Helvetica, sans-serif;
color: 
black;
font-size: 15px;
direction: rtl;
}
</style>
</head>

<body>
<?php 
	/*echo '<pre>';print_r($exam_student_array);echo '</pre>';
	echo '<pre>';print_r($exam_date_sheet);echo '</pre>';	
	die();*/
$count = 1; foreach ($exam_student_array as $key => $esinfo) {?>
		<div class="pad border">
  <table width="100%" border="0">
    <tbody><tr>
      <td class="centerAlign title" style="font-size:30px">رابطۃ المدارس الاسلامیہ پاکستان</td>
    </tr>
    <tr>
      <td class="centerAlign"><?php echo $esinfo['exam_name'];?></td>
    </tr>
  </tbody></table>
  <table style="padding-bottom:30px;" width="100%" border="0">
    <tbody><tr>
      <td width="8%">&nbsp;</td>
		<td width="8%" rowspan="4" class="border">
			<?php if($esinfo['std_image'] != ""){?>
				<img src="<?php echo base_url();?>student_images/<?php echo $esinfo['std_image'];?>" alt="Student Image" width="90" height="100" />
			<?php }?>
		</td>
	        
      <td width="6%">&nbsp;</td>
      <td class="centerAlign border"><?php echo $esinfo['std_reg_no'];?></td>
      <td>:رقم التسجیل</td>
      <td width="5%" class="centerAlign">&nbsp;</td>
      <td width="15%" class="centerAlign border"><?php echo $esinfo['std_roll_no'];?></td>
      <td class="centerAlign">&nbsp;</td>
      <td width="10%" class="rightAlign">:رقوم الجلوس</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td id="dostyle" width="20%" class="centerAlign border"><?php echo $esinfo['std_father_name'];?></td>
      <td width="12%" class="leftAlign">:اسم&nbsp;الوالد</td>
      <td id="dostyle" colspan="2" class="centerAlign border"><?php echo $esinfo['std_name'];?></td>
      <td class="centerAlign">&nbsp;</td>
      <td class="rightAlign">:اسم الطالب</td>
    </tr>
    <tr>
      <td class="rightAlign">&nbsp;</td>
      <td class="rightAlign">&nbsp;</td>
      <td colspan="4" class="centerAlign border"><?php echo $esinfo['affli_fullname'];?></td>
      <td width="1%">&nbsp;</td>
      <td class="rightAlign">اسم&nbsp;المدرستہ</td>
    </tr>
    <tr>
      <td class="rightAlign">&nbsp;</td>
      <td class="rightAlign">&nbsp;</td>
      <td colspan="4" class="centerAlign border"><?php echo $esinfo['exam_center_name_urdu'];?></td>
      <td>&nbsp;</td>
      <td class="rightAlign">مرکز&nbsp;الامتحان</td>
    </tr>
  </tbody>
  </table>
  <div class="tablee">
  <?php if($esinfo['exam_type_id'] == 2){?>

	   
	    <table width="100%" border="0" cellspacing="0">
	      <tbody>
		      <tr>
		        <td width="20%" class="border centerAlign">وقت</td>
		        <td width="20%" class="border centerAlign">الوقت الثانی</td>
		        <td width="20%" class="border centerAlign">وقت</td>
		        <td width="20%" class="border centerAlign">تاریخ</td>
		        <td width="20%" class="border centerAlign">مضمون</td>
		      </tr>
		      <?php $sub_name_urdu =  explode(',', $esinfo['sub_name_urdu']);
		      		$subject_id =  explode(',', $esinfo['sub_id']);
		      		$exam_date =  explode(',', $esinfo['exam_date']);
		      		// var_dump($sub_name_urdu);
		      		// die();
		      		// var_dump($exam_date);
		      		// /die();
		      		$ci =&get_instance();
					$ci->load->model('admin_model');
					$strFinal = "<tr>";
					$strStart = '<td class="border centerAlign">&nbsp;</td><td class="border centerAlign">&nbsp;</td>';
					$midArea = "";
					$prevDate = NULL;
					$i = 0;
					$loopcount = 0;
					$empty = true;
		      foreach($sub_name_urdu AS $key => $sub){// echo $sub;?>

		      	<?php 

		      			// echo 'subject_id'.$subject_id[$key].'<br/>';
		      			// echo $exam_date[$key].'<br/>';
		      			$response = $ci->admin_model->searcharray($subject_id[$key],'exam_subject_id',$exam_date_sheet);

		      			/*$nextdate = strtotime($exam_date[$key]);
		      					if (strtotime($prevDate) == $nextdate) {

		      						// die($loopcount.$sub);
		      						$i++;
		      						$temp = '<td class="border centerAlign">'.$exam_date_sheet[$response]['exam_date'].'</td>' .'<td class="border centerAlign">'.$sub.'</td>';
						        	$midArea = $temp .$midArea;
		      						$empty = false;	
		      						$loopcount++;

		      					}else{

		      						
		      						if ($loopcount == 0) {
		      							
		      							if($i == 0){

			      							if($exam_date_sheet[$response]['exam_appearance_time'] == 'first_time'){

			      								$midArea .= '<td class="border centerAlign" dir="rtl">'.$exam_date_sheet[$response]["exam_time"].'بجے صبح</td>';
			      								$midArea .= '<td class="border centerAlign">'.$exam_date_sheet[$response]['exam_date'].'</td>';
							        			$midArea .= '<td class="border centerAlign">'.$sub.'</td>';

			      							}else{

			      								$midArea .= '<td class="border centerAlign" dir="rtl">'.$exam_date_sheet[$response]["exam_time"].'بجے دوپہر</td>';
			      								$midArea .= '<td class="border centerAlign">'.$exam_date_sheet[$response]['exam_date'].'</td>';
							        			$midArea .= '<td class="border centerAlign">'.$sub.'</td>';
			      							
			      							}
			      							
		      							}

		      						}
							        
							       
		      					}// end else for $exam_date[$key] == $prevDate*/

		      					/*if ($key != 0 ){
		      								
	  								if($i == 0 and $empty and $loopcount == 1){
	  									// die();
	  									//die($loopcount.$sub);
		      							$strFinal .= $strStart.$midArea.'</tr>';
	      								$loopcount = 0;

	      							}elseif($loopcount == 2 and !$empty){
	      								// /die($loopcount.$sub.'test');
	      								$strFinal .= $midArea.'</tr>';
										$empty = false;
										$loopcount = 0;
	      							}

	      							$i = 0;
	  							}

		      					$loopcount++;
		      					$prevDate = $exam_date[$key];*/
		      					// echo $prevDate = $exam_date[$key].'<br/>';      					
		      					?>

						        <?php  if($exam_date_sheet[$response]['exam_appearance_time'] == 'first_time'){?>
						        <tr>
						        	<td class="border centerAlign">&nbsp;</td>
						        	<td class="border centerAlign">&nbsp;</td>
						        	<td class="border centerAlign" dir="rtl"><?php echo $exam_date_sheet[$response]['exam_time'].'بجے صبح';?></td>
						        	<td class="border centerAlign"><?php echo $exam_date_sheet[$response]['exam_date'];?></td>
						        	<td class="border centerAlign"><?php echo $sub;?></td>
						        </tr>
						        <?php }else{?>
						        <tr>
						        	<td class="border centerAlign" dir="rtl"><?php echo $exam_date_sheet[$response]['exam_time'].'بجے دوپہر';?></td>
						        	<td class="border centerAlign"><?php echo $sub;?></td>
						        	<td class="border centerAlign">&nbsp;</td>
						        	<td class="border centerAlign"><?php echo $exam_date_sheet[$response]['exam_date'];?></td>
						        	<td class="border centerAlign">&nbsp;</td>
						        </tr>
						        <?php }?>
	         <?php } // end foreach loop for subjects ?>

	         <?php 
	         /*if ($empty) {
			    $strFinal = $strStart . $midArea ."</tr>";
			 }
			 // $strFinal = $strFinal . "</tr>";
			 echo $strFinal;*/
			 ?>
	      	  <tr>
		        <td colspan="2" class="centerAlign">ختم&nbsp;الرابطہ</td>
		        <td colspan="2">&nbsp;</td>
		        <td colspan="2" class="centerAlign">توقیع&nbsp;مراقب&nbsp;الامتحان</td>
		      </tr>
	      </tbody>
	    </table>
	    <?php //echo '<pre>';print_r($exam_date_sheet);echo '</pre>';
	    //die();?>

   <?php }else{?>

   	    <table width="100%" border="0" cellspacing="0">
      	   <tbody>
	      <tr>
	        <td width="20%" class="border centerAlign">وقت</td>
	        <td width="20%" class="border centerAlign">الوقت الثانی</td>
	        <td width="20%" class="border centerAlign">وقت</td>
	        <td width="20%" class="border centerAlign">تاریخ</td>
	        <td width="20%" class="border centerAlign">مضمون</td>
	      </tr>
	      <tr>
	        <td class="border centerAlign">&nbsp;</td>
	        <td class="border centerAlign">&nbsp;</td>
	        <td class="border centerAlign">بجے صبح 8:00</td>
	        <td class="border centerAlign">16-05-2015</td>
	        <td class="border centerAlign"><?php echo $exam_subject[0]['sub_name_urdu']?></td>
	      </tr>
          <tr>
	        <td class="border centerAlign">بجے دوپہر 2:00</td>
	        <td class="border centerAlign"><?php echo $exam_subject[6]['sub_name_urdu'];?></td>
	        <td class="border centerAlign">بجے صبح 8:00</td>
	        <td class="border centerAlign">17-05-2015</td>
	        <td class="border centerAlign"><?php echo $exam_subject[1]['sub_name_urdu'];?></td>
	      </tr>
          <tr>
	        <td class="border centerAlign">بجے دوپہر 2:00</td>
	        <td class="border centerAlign"><?php echo $exam_subject[7]['sub_name_urdu'];?></td>
	        <td class="border centerAlign">بجے صبح 8:00</td>
	        <td class="border centerAlign">18-05-2015</td>
	        <td class="border centerAlign"><?php echo $exam_subject[2]['sub_name_urdu'];?></td>
	      </tr>
	      <tr>
	        <td class="border centerAlign">بجے دوپہر 2:00</td>
	        <td class="border centerAlign"><?php echo $exam_subject[8]['sub_name_urdu'];?></td>
	        <td class="border centerAlign">بجے صبح 8:00</td>
	        <td class="border centerAlign">19-05-2015</td>
	        <td class="border centerAlign"><?php echo $exam_subject[3]['sub_name_urdu'];?></td>
	      </tr>
	      <tr>
	        <td class="border centerAlign">بجے دوپہر 2:00</td>
	        <td class="border centerAlign"><?php echo $exam_subject[9]['sub_name_urdu'];?></td>
	        <td class="border centerAlign">بجے صبح 8:00</td>
	        <td class="border centerAlign">20-05-2015</td>
	        <td class="border centerAlign"><?php echo $exam_subject[4]['sub_name_urdu'];?></td>
	      </tr>
	      <tr>
	      	<td class="border centerAlign">&nbsp;</td>
	        <td class="border centerAlign">&nbsp;</td>
	        <td class="border centerAlign">بجے صبح 8:00</td>
	        <td class="border centerAlign">21-05-2015</td>
	        <td class="border centerAlign"><?php echo $exam_subject[5]['sub_name_urdu'];?></td>
	      </tr>
	      
	      </tr>
      	  <tr>
	        <td colspan="2" class="centerAlign">ختم&nbsp;الرابطہ</td>
	        <td colspan="2">&nbsp;</td>
	        <td colspan="2" class="centerAlign">توقیع&nbsp;مراقب&nbsp;الامتحان</td>
	      </tr>
    	   </tbody>
    </table>

   <?php }?>
  </div>
</div>
	<?php if( ($count %2 == 0) ){?>
    	<div style="page-break-after:always"></div>
  	<?php }// end check for $key ?>
<?php $count++; }?>
</body>
</html>